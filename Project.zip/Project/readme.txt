Per far girare il codice:
1) Scaricare il dataset train_V2.csv da questo indirizzo https://www.kaggle.com/c/pubg-finish-placement-prediction/data
2) Rinominarlo dataset.csv
3) Posizionarlo nella cartella ./data